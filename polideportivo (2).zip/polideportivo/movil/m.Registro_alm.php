<?php session_start();?>
<!DOCTYPE html>
<html>
<head>

<link href="m.estilos.css" type="text/css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="boilerplate.css" rel="stylesheet" type="text/css">
<script src="respond.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registro</title>

</head>
<body>
<div class="CONT" align="center" >

   

    <div>

        <div id ="Cabecera">

            <div id="ContenidoCabecera">
                <div id="BarraArriba">
                    <ul>
                        <li> <a href="m.Principal.php"> Inicio </a></li>
                        <li> <a href="m.R.php"> Registro </a></li>
                        <li> <a href="m.Reservacion.php"> Reservación </a></li>
						<li> <a href="m.Torneo.php"> Torneos </a></li>
						 <li> <a href="m.Reto.php"> Retos </a></li>
						 <li> <a href="m.Historial.php"> Historial </a></li>
                        <li> <a href="m.AcercaDe.php"> AcercaDe </a></li>
						<!--<li> <a href="m.loggin.php"> loggin </a></li>-->
						
                    </ul>
                </div>
                <div id="Logotipo">                   

                    <img src="Imagenes/logo3.png" alt="logo" style="height:40px; width:244px;"/>

                </div>
                <div id="Titulo">
                    
                </div>

            </div>

        <div id ="Bajo">
            <div id ="ColumnaIzquierda">
                
    <ul id="MenuContextual">
        <li> <a href="m.Registro_alm.php">Registro de Usuario </a> </li>
        
    </ul>

            </div>
            <div id="ColumnaCentro">
                
    
   <!-- ------------------- -->
   
	  <article class="contact">
	  
	  <section class="contact">
	  <form action="m.Registro_alm.php" method="post">
                        <legend><h1>Formulario de registro</h1></legend>
                        <ol>
                            <li>
                              Nombre<br>
							  <input type="text" id="NombreDeUsuario" placeholder="Nombre" name="NombreDeUsuario">
                            </li>
							
							<li>
                              Apellido<br>
							  <input type="text" id="NombreDeUsuario2" placeholder="Apellido" name="NombreDeUsuario2">
                            </li>
						     <li>
							
                             Contraseña<br>
                             <input type="password" id="Password"  placeholder="Contraseña" name="Password"> 
							</li>  
                             <li>
                                Numero de Cuenta<br>
                                <input type="text" id="NCuenta" placeholder="Numero de cuenta" name="NCuenta">
                                
                            </li>							
                            <li>
                                Seleccione Carrera<br>
								<select name="Carrera" id="Carrera" placeholder=""> 
								
							                                                      
								<option value="Ing. en Informática">Ing. en Informática</option>
								<option value="Lic. en Administración de Empresas">Lic. en Administración de Empresas</option>
                                <option value="Lic. en Turismo">Lic. en Turismo</option>
								<option value="Lic. en Diseño Gráfico">Lic. en Diseño Gráfico</option>
								<option value="Lic. en Derecho">Lic. en Derecho</option>
								<option value="Lic. en Mercadotécnia">Lic. en Mercadotécnia</option>
								<option value="Lic. en Contaduría y Finanzas">Lic. en Contaduría y Finanzas</option>
								<option value="Lic. en Recursos Humanos">Lic. en Recursos Humanos</option>
                                </select>
                                <!--<input type="text" id="Carrera" placeholder="nformatica" name="Carrera">-->
                                
                            </li>
							<li>
							
                            Correo Electronico<br>
                            <input type="text" id="Email" placeholder="Correo" name="Email">@unitec.edu
                                
                            </li>
							
							<li>
							
                            Telefono<br>
                            <input type="text" id="Telefono" placeholder="Telefono" name="Telefono">
                                
                            </li>
     
                           
						  
							
                        </ol>
						<input type="submit" value="Registrarse">
                        </form></section>
						<div id="msj" name="msj"></div>
                    </article>

   
   <!-- --------------------- -->

            </div>
            <div id="ColumnaDerecha">

                

                <div id="Enlaces">
                  </div><div><?php //echo "".$_SESSION['cuenta'];?></div>
				  <section id="login" align="right">
                    
                            <ul>
                                <li><a href="m.R.php" id="LoginView1_registerLink">Registrarse</a></li>
                                <li><a href="m.loggin.php" id="LoginView1_loginLink"><br><br>Iniciar sesión</a></li>
								<li> <a href="m.salir.php"><br><br> salir </a></li>
                            </ul>
                        
                </section>
				<div id="ImagenLogo">
				  <img src="Imagenes/logosimple.png" alt="logo" style="height:73px; width:85px; text-align: center;"/>
                  </div> 
				
                </div>
            </div>
            <div id="Pie">
			<div id="scroll" align="right">
                <a title="Desplazar hacia arriba" class="top" href="#"><img src="top.png" alt="top" /></a>
                </div>
				<script type="text/javascript">
                $(document).ready(function() {
                $('ul.sf-menu').sooperfish();
                $('.top').click(function() {$('html, body').animate({scrollTop:0}, 'fast'); return false;});
                 });
                </script>
                <span> &copy; 2014 - Solicitud para reservación de canchas del polideportivo
				
				<div align="center">
				<?php
				if($_SESSION['Unombre']!="")
				{
				echo $_SESSION[Unombre];
				echo "<a href='"."m.salir.php"."'>( Cerrar Sesion )</a>";
				}
				?>
				
				</div>
				<br>
				</span>             
                         
            </div>
        </div>
    </div>
        </div>

    
	
	
	</div>
	
	
	


<!-- Inicio php insert -->
<?php                  //db4free.net","ceutec","ceutec"
$conexion=mysql_connect("db4free.net","ceutec","ceutec") or
 die("Problemas en la conexion");
mysql_select_db("ceutec",$conexion) or
  die("Problemas en la selección de la base de datos");
 // echo "< script>alert('ok');</script>";
  
  if("" != $_REQUEST[Carrera] or "" != $_REQUEST[Telefono] or $_REQUEST[NombreDeUsuario] != "" or $_REQUEST[NombreDeUsuario2] != "" or $_REQUEST[Password] !="" or $_REQUEST[NCuenta]!="" or $_REQUEST[Email]!="")
  {
  
  if(is_numeric($_REQUEST[NCuenta]) and strlen($_REQUEST[NCuenta])==8 ){
  
  if("" != $_REQUEST[Carrera] and "" != $_REQUEST[Telefono] and $_REQUEST[NombreDeUsuario] != "" and $_REQUEST[NombreDeUsuario2] != "" and $_REQUEST[Password] !="" and $_REQUEST[NCuenta]!="" and $_REQUEST[Email]!="" and strlen($_REQUEST[NCuenta])==8)
  {

  
  //-----
 
  $registros=mysql_query("select IdEstudiante,Correo from estudiantes where IdEstudiante='$_REQUEST[NCuenta]' or correo='$_REQUEST[Email]'",$conexion) or
  die("Problemas en el select1:".mysql_error());
  
  #
    while($row = mysql_fetch_array($registros))
  {
  
   $numerocuent=$row['IdEstudiante'];
   $corre=$row['Correo'];
  
 }
  #
  
//  echo " row cuenta: ".$numerocuent;
  //echo " row corre: ".$corre;
  
//  echo " rquest cuenta: ".$_REQUEST[NCuenta];
  
  //  echo " rquest emial: ".$_REQUEST[Email];
  
 
  
  
  if($numerocuent==$_REQUEST[NCuenta] or $corre == $_REQUEST[Email]){

echo '<script>document.getElementById("msj").innerHTML ="El correo/Numero de cuenta ingresado ya esta registrado<br> en caso de ser suyos Visite el area deportiva, para darle<br> seguimiento a su caso.";</script>'; 
 
                                                                        
  
  }else{
  //------
  
   $MMMM="".$_REQUEST[Email]."@unitec.edu";
  //INICIO INSERT____________________________________________
  $numeroAleatorio = rand(0,10000);
  $registros=mysql_query("insert into temp(nombret,apellidot,telefonot,contrat,numerocuentat,carrerat,correot,num) values ('$_REQUEST[NombreDeUsuario]','$_REQUEST[NombreDeUsuario2]','$_REQUEST[Telefono]','$_REQUEST[Password]','$_REQUEST[NCuenta]','$_REQUEST[Carrera]','$MMMM',$numeroAleatorio)",$conexion) or
  die("Problemas Registrando datos en temp:".mysql_error());
  #punciona ;) 3 hora en eto
  
  /*INICIAMOS EL CODIGO PHP*/
$header="From: AREA DEPORTIVA:<$_REQUEST[Email]>\n";
/*CREAMOS UN HEADER DONDE DEFINIMOS EL REMITENTE DEL CORREO,
ESTO LO ASIGNAMOS A LA VARIABLE $header*/
$header.="MIME-Version: 1.0\n";
$header.="Content-type: text/html; charset=iso-8859-1";
/*CONTINUAMOS EL HEADER (NOTESE EL ".=" EN VEZ DE SOLO "="),
DEFINIDIENDO AHORA, QUE EL CORREO SE ENVIARA EN FORMATO HTML.
ESTO TAMBIEN LO ASIGNAMOS A LA VARIABLE $header*/
$msj="Bienvenido a polideportivo ceutec ".$_REQUEST[NombreDeUsuario]."<br>
      aqui enlistamos sus datos:<br>Nombre:".$_REQUEST[NombreDeUsuario]."
	  <br>Apellido:".$_REQUEST[NombreDeUsuario2]." <br>Contraseña:".$_REQUEST[Password]."<br>Numero de cuenta:".$_REQUEST[NCuenta]."
	  <br> Carrera:".$_REQUEST[Carrera]."<br>Correo:".$_REQUEST[Email]."@unitec.edu
	  <br>Telefono:".$_REQUEST[Telefono]."
	  <br>Para verificar su correo ingresar
	  <br>En el siguiente url, introducir numero de cuenta y este numero:".$numeroAleatorio."
	  <br><a href='http://appletenhtml.comule.com/polideportivo/movil/m.verificar.php'>Verificar cuenta polideportivo</a>
	  <br>Te esperamos en el polideportivo<br><h1>SALUDOS!</h1>";
//$msj.="<br><a href='www.comolohago.cl'>Click</a>";
/*CREAMOS EL MENSAJE (NOTESE NUEVAMENTE EL ".=") QUE IRA EN EL CORREO
Y LO ASIGNAMOS A LA VARIABLE $msj*/
$dest=$_REQUEST[Email]."@unitec.edu";
/*ASIGNAMOS A LA VARIABLE $dest EL CORREO AL QUE ENVIAREMOS EL CORREO
LAS PRUEBAS DEBEN HACERSE CON UN CORREO REAL*/
$asunto="Confirmacion de registro";
/* EN LA VARIABLE $asunto GUARDAMOS EL ASUNTO DEL MENSAJE*/
mail($dest,$asunto,$msj,$header);
/*EJECUTAMOS LA FUNCION COMO TAL, EL ORDEN ES IMPORTANTE ASI QUE SE DEBE MANTENER,
USAMOS LAS VARIABLES QUE ASIGNAMOS ANTERIORMENTE*/
//echo "Mensake enviado";
   echo '<script>document.getElementById("msj").innerHTML = "Se le a enviado un menaje de<br>verificacion revise su correo.";</script>'; 

    //FIN INSERT____________________________________________
  }
  
 // echo '<script> alert("Se le a enviado un menaje de<br>verificacion revise su correo.");</script>';
   } else {
  
   
   echo '<script>document.getElementById("msj").innerHTML = "NOTA: Introducir todos los datos.";</script>';  
   echo '<script>document.getElementById("NombreDeUsuario").value = "'.$_REQUEST[NombreDeUsuario].'";</script>';
   echo '<script>document.getElementById("NombreDeUsuario2").value = "'.$_REQUEST[NombreDeUsuario2].'";</script>';
   echo '<script>document.getElementById("Password").value = "'.$_REQUEST[Password].'";</script>';
   echo '<script>document.getElementById("NCuenta").value = "'.$_REQUEST[NCuenta].'";</script>';
   echo '<script>document.getElementById("Carrera").value = "'.$_REQUEST[Carrera].'";</script>';
   echo '<script>document.getElementById("Telefono").value = "'.$_REQUEST[Telefono].'";</script>';
   echo '<script>document.getElementById("Email").value = "'.$_REQUEST[Email].'";</script>';
   
   
   
  
  }

  }else{
  
   
  
  
     echo '<script>document.getElementById("msj").innerHTML = "Numero de cuenta incorrecta.";</script>'; 
     echo '<script>document.getElementById("NombreDeUsuario").value = "'.$_REQUEST[NombreDeUsuario].'";</script>';
     echo '<script>document.getElementById("NombreDeUsuario2").value = "'.$_REQUEST[NombreDeUsuario2].'";</script>';
     echo '<script>document.getElementById("Password").value = "'.$_REQUEST[Password].'";</script>';
     echo '<script>document.getElementById("NCuenta").value = "'.$_REQUEST[NCuenta].'";</script>';
     echo '<script>document.getElementById("Carrera").value = "'.$_REQUEST[Carrera].'";</script>';
	 echo '<script>document.getElementById("Telefono").value = "'.$_REQUEST[Telefono].'";</script>';
     echo '<script>document.getElementById("Email").value = "'.$_REQUEST[Email].'";</script>';
	 
	  if (strlen($_REQUEST[NCuenta]!=8) and $_REQUEST[Email]!="")
   {
   echo '<script>document.getElementById("msj").innerHTML = "Numero de cuenta incorrecto.";</script>';
   }
                
				
				}
  
  
  }
  
mysql_close($conexion);
  
  ?>
</body>
</html>
