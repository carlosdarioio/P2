<?php
 session_start();
 unset($_SESSION['name']);
 unset( $_SESSION['cuenta']);
     session_destroy();
 header('Location: m.Principal.php');
?>
